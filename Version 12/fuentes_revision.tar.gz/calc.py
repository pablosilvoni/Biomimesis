import numpy as np, json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","mathtext.fontset":"cm","font.size":9,"axes.grid":True,"grid.alpha":.3,"figure.dpi":150,"savefig.bbox":"tight"})
P0=13.32; kPa2mmHg=7.50062
C={ # nombre: (h0,Pa,lam,sigma,Pi_orig)
"Jóvenes normotensos (Mean Young)":(0.1703,5.63,[1,1.02,1.04,1.06,1.08,1.10,1.115,1.12,1.14,1.16,1.18],[0,5.45,13.00,22.65,34.39,48.24,60.00,64.18,82.23,102.37,124.61],[5.63,6.46,7.54,8.85,10.36,12.06,13.44,13.92,15.92,18.05,20.30]),
"Mayores normotensos (Mean Old)":(0.2072,5.61,[1,1.02,1.04,1.06,1.08,1.092,1.10,1.12,1.14,1.16,1.18],[0,7.32,19.26,35.84,57.05,72.00,82.89,113.36,148.47,188.20,232.57],[5.61,6.94,9.01,11.73,15.05,17.30,18.90,23.23,27.99,33.14,38.64]),
"Normotensos de control (Mean NT)":(0.1852,5.62,[1,1.02,1.04,1.06,1.08,1.095,1.10,1.12,1.14,1.16,1.18],[0,6.67,17.08,31.23,49.13,65.00,70.76,96.13,125.25,158.10,194.70],[5.62,6.72,8.33,10.42,12.94,15.07,15.83,19.06,22.60,26.41,30.46]),
"Hipertensos tratados (Mean HT)":(0.2197,5.98,[1,1.02,1.04,1.06,1.075,1.08,1.10,1.12,1.14,1.16,1.18],[0,10.23,28.92,56.08,82.00,91.70,135.78,188.32,249.32,318.79,396.72],[5.98,7.95,11.36,16.09,20.41,22.00,28.97,36.90,45.70,55.27,65.54]),
}
def xk(l,h0,lz=1.0): return np.sqrt(1+((1+h0)**2-1)/(l**2*lz))-1
def urq(x): return 2*x/(2+x)
out={}; tex=[]; maxdiff={}
short={"Jóvenes normotensos (Mean Young)":"3","Mayores normotensos (Mean Old)":"4","Normotensos de control (Mean NT)":"5","Hipertensos tratados (Mean HT)":"6"}
for k,(h0,Pa,lam,sig,Po) in C.items():
    lam=np.array(lam); sig=np.array(sig); x=xk(lam,h0)
    Pw=sig*np.log1p(x); Pi=Pw+Pa; Pu=sig*urq(x)+Pa; err=100*(Pu-Pi)/Pi
    maxdiff[k]=float(np.max(np.abs(Pi-np.array(Po))))
    rows=[]
    for i in range(len(lam)):
        rows.append(f"{lam[i]:.3f} & {sig[i]:.2f} & {x[i]:.3f} & {Pw[i]:.2f} & {Pi[i]:.2f} & {Pi[i]*kPa2mmHg:.1f} & {Pi[i]/P0:.3f} & {Pu[i]:.2f} & {err[i]:+.2f}\\,\\% \\\\")
    open(f"tab_{short[k]}.tex","w").write("\n".join(rows)+"\n")
    out[k]=dict(Pi=Pi.tolist(),lam=lam.tolist())
print("max |Pi_recalc - Pi_original| por cohorte:",{k[:12]:round(v,3) for k,v in maxdiff.items()})
# --- Tabla 2 consistencia geométrica
G={"Jóvenes":(1.115,3.48,0.48,3.82,60.0,7.79,5.63,13.42,0.1703),"Mayores":(1.092,3.77,0.62,4.25,72.0,11.15,5.61,16.76,0.2072),"Hipertensos":(1.075,3.87,0.73,4.45,82.0,14.42,5.98,20.40,0.2197)}
rows=[];geo={}
for k,(l,ri,h,rmd,s,Pw_rep,Pa,Pi_rep,h0) in G.items():
    rm=ri+h; A=rm**2-ri**2
    Ri=np.sqrt(A/((1+h0)**2-1)); Rm=np.sqrt(Ri**2+A)
    li=ri/Ri; lm=rm/Rm
    Pw_geo=s*np.log(1+h/ri); Pw_kin=s*np.log1p(xk(l,h0))
    Pw_z=s*np.log1p(xk(l,h0,1.10))
    geo[k]=dict(li=li,lm=lm,Pw_geo=Pw_geo,Pw_kin=Pw_kin,Pw_z=Pw_z,x_geo=h/ri,x_kin=xk(l,h0),x_z=xk(l,h0,1.10))
    rows.append(f"{k} & {l:.3f} & {li:.3f} & {lm:.3f} & {h/ri:.3f} & {xk(l,h0):.3f} & {Pw_rep:.2f} & {Pw_geo:.2f} & {Pw_kin:.2f} \\\\")
open("tab_geo.tex","w").write("\n".join(rows)+"\n")
print(json.dumps(geo,indent=1,default=float))
# --- Sensibilidad axial: efecto sobre P_pared
rows=[]
for k,(l,ri,h,rmd,s,Pw_rep,Pa,Pi_rep,h0) in G.items():
    g=geo[k]; rows.append(f"{k} & {g['x_kin']:.3f} & {g['x_z']:.3f} & {g['Pw_kin']:.2f} & {g['Pw_z']:.2f} & {100*(g['Pw_z']/g['Pw_kin']-1):+.1f}\\,\\% \\\\")
open("tab_lz.tex","w").write("\n".join(rows)+"\n")
# --- Pa de Masson (Tabla 4 HT)
a=np.array([.098,.137,.113,.099,.033,.004,.078,.084,.023,.114,.115,.090,.009,.088,.085,.039,.099,.094,.097,.100,.094,.097,.094,.043,.025])
b=np.array([3.50,3.58,3.62,3.51,3.56,3.54,3.72,3.56,3.55,3.47,3.59,3.58,3.49,3.52,3.63,3.52,3.60,3.56,3.55,3.47,3.57,3.61,3.56,3.58,3.46])
res={}
for r in (1.0,1.034,1.06):
    Pa_i=a*np.exp(b*r); res[r]=(Pa_i.mean(),Pa_i.std(ddof=1),np.median(Pa_i),Pa_i.min(),Pa_i.max())
print("n",len(a),"Pa(r) mean,sd,med,min,max:",{k:[round(v,2) for v in vv] for k,vv in res.items()})
print("a e^b medias:",0.078*np.exp(3.56))
# sensibilidad de sigma_bar a Pa para punto fisiológico
rows=[];sens={}
for k,(l,ri,h,rmd,s,Pw_rep,Pa,Pi_rep,h0) in G.items():
    x=xk(l,h0); L=np.log1p(x)
    vals=[(Pi_rep-p)/L for p in (Pa,3.10,2.75,0.0)]
    sens[k]=vals
    rows.append(f"{k} & {Pi_rep:.2f} & {s:.1f} & {vals[0]:.1f} & {vals[1]:.1f} & {vals[2]:.1f} & {vals[3]:.1f} \\\\")
open("tab_sens.tex","w").write("\n".join(rows)+"\n")
print(sens)
# --- Padé vs Laplace
xs=np.array([0,0.05,0.10,0.12,0.15,0.18,0.20,0.25])
rows=[]
for x in xs:
    if x==0: rows.append("0{,}00 & 1{,}00000 & 0{,}00000 & 0{,}00000 & $+0{,}000\\,\\%$ & 0{,}00000 & $+0{,}00\\,\\%$ \\\\"); continue
    ex=np.log1p(x);pd=urq(x);la=x
    f=lambda v:f"{v:.5f}".replace(".","{,}")
    rows.append(f"{x:.2f} & {1+x:.2f} & {f(ex)} & {f(pd)} & ${100*(pd-ex)/ex:+.3f}\\,\\%$ & {f(la)} & ${100*(la-ex)/ex:+.2f}\\,\\%$ \\\\".replace(".","{,}",3) if False else f"{x:.2f} & {1+x:.2f} & {ex:.5f} & {pd:.5f} & {100*(pd-ex)/ex:+.3f}\\,\\% & {la:.5f} & {100*(la-ex)/ex:+.2f}\\,\\% \\\\")
open("tab_pade.tex","w").write("\n".join(rows)+"\n")
print("Pade err x=.2:",100*(urq(.2)-np.log1p(.2))/np.log1p(.2)," x=.189:",100*(urq(.189)-np.log1p(.189))/np.log1p(.189))
# --- figuras
xx=np.linspace(0.001,0.30,300); ex=np.log1p(xx)
fig,ax=plt.subplots(2,1,figsize=(5.4,5.2),sharex=True,gridspec_kw={"height_ratios":[1.3,1]})
ax[0].plot(xx,ex,"k-",label=r"$\ln(1+x)$ (exacta)");ax[0].plot(xx,urq(xx),"C0--",label=r"Padé $[1/1]$: $2x/(2+x)$");ax[0].plot(xx,xx,"C3:",label=r"Laplace: $x$")
for a_ in ax: a_.axvspan(.10,.20,color="gold",alpha=.25)
ax[0].set_ylabel(r"factor logarítmico");ax[0].legend(fontsize=7)
ax[1].plot(xx,100*(urq(xx)-ex)/ex,"C0--",label="Padé [1/1]");ax[1].plot(xx,100*(xx-ex)/ex,"C3:",label="Laplace");ax[1].axhline(0,color="k",lw=.6)
ax[1].set_xlabel(r"$x=h/r_i$");ax[1].set_ylabel("error relativo [%]");ax[1].legend(fontsize=7)
fig.savefig("fig/f_pade.pdf");plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.2,3.2))
cols=["C0","C1","C2","C3"]
exv=lambda l:0.1427*(np.exp(11.9103*(l-1))-1)
for (k,v),c in zip(out.items(),cols):
    lam=np.array(v["lam"]);Pi=np.array(v["Pi"])
    axs[0].plot(lam,Pi,"o-",ms=3,color=c,label=k.split("(")[1].rstrip(")"))
    axs[1].plot(lam,Pi/P0,"o-",ms=3,color=c)
lv=np.linspace(1,1.42,200)
axs[0].plot(lv,exv(lv),"k-",label="Ex vivo (donante VI r, ajuste)");axs[1].plot(lv,exv(lv)/P0,"k-")
axs[0].set_ylabel(r"$P_i$ [kPa]");axs[1].set_ylabel(r"$P_i/P_0$");axs[1].axhline(1,color="gray",ls="--",lw=.8)
for a_ in axs:a_.set_xlabel(r"$\lambda_\theta$");a_.set_xlim(1,1.42)
axs[0].set_ylim(0,70);axs[1].set_ylim(0,5.2);axs[0].legend(fontsize=6)
fig.tight_layout();fig.savefig("fig/f_super.pdf");plt.close(fig)
print("P0 cruce ex vivo:",1+np.log(P0/0.1427+1)/11.9103)
print("ex vivo:",[round(exv(l),2) for l in (1.2,1.3,1.4)])
